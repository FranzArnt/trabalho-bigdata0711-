Trabalho de extenção da disciplina Tópicos de Big Data em Python.
Abrir o arquivo trabalho_big_data.ipynb no Google Colab e fazer upload da planilha vendas.xlsx.
